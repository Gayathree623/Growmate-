Frontend (Vite + React)
-----------------------
1. cd frontend
2. npm install
3. npm run dev

Notes:
- Navigation is in src/components/Navigation.jsx
- Pages are in src/pages/
- Logos in src/assets/logos/
- Home is routed to "/"