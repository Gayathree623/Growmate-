import Page1 from './pages/home_page.jsx'
import Page2 from './pages/login_signup.jsx'
import Page3 from './pages/user_profile.jsx'
import Page4 from './pages/daily_planner_to-do.jsx'
import Page5 from './pages/calendar.jsx'
import Page6 from './pages/study_timer.jsx'
import Page7 from './pages/reminder_and_notifications.jsx'
import Page8 from './pages/period_tracker.jsx'
import Page9 from './pages/stress_level_quiz.jsx'
import Page10 from './pages/feedback_engine.jsx'
import Page11 from './pages/breathing_exercises.jsx'
import Page12 from './pages/gratitude_journal.jsx'
import Page13 from './pages/weekly_reflection_page.jsx'
import Page14 from './pages/mood_journal.jsx'
import Page15 from './pages/habit_tracker.jsx'
import Page16 from './pages/affirmation_generator.jsx'
import Page17 from './pages/goal_tracker.jsx'
import Page18 from './pages/achievement_badges.jsx'
import Page19 from './pages/resource_library.jsx'
import Page20 from './pages/theme_customization.jsx'
import Page21 from './pages/export_center.jsx'
import Page22 from './pages/settings_and_privacy.jsx'
import Page23 from './pages/admin_dashboard.jsx'

import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import './components/Navigation.css'
import Navigation from './components/Navigation'

export default function App() {
  return (
    <div>
      <Navigation />
      <Routes>
  <Route path="/" element={<Page1 />} />
  <Route path="/login_signup" element={<Page2 />} />
  <Route path="/user_profile" element={<Page3 />} />
  <Route path="/daily_planner_to-do" element={<Page4 />} />
  <Route path="/calendar" element={<Page5 />} />
  <Route path="/study_timer" element={<Page6 />} />
  <Route path="/reminder_and_notifications" element={<Page7 />} />
  <Route path="/period_tracker" element={<Page8 />} />
  <Route path="/stress_level_quiz" element={<Page9 />} />
  <Route path="/feedback_engine" element={<Page10 />} />
  <Route path="/breathing_exercises" element={<Page11 />} />
  <Route path="/gratitude_journal" element={<Page12 />} />
  <Route path="/weekly_reflection_page" element={<Page13 />} />
  <Route path="/mood_journal" element={<Page14 />} />
  <Route path="/habit_tracker" element={<Page15 />} />
  <Route path="/affirmation_generator" element={<Page16 />} />
  <Route path="/goal_tracker" element={<Page17 />} />
  <Route path="/achievement_badges" element={<Page18 />} />
  <Route path="/resource_library" element={<Page19 />} />
  <Route path="/theme_customization" element={<Page20 />} />
  <Route path="/export_center" element={<Page21 />} />
  <Route path="/settings_and_privacy" element={<Page22 />} />
  <Route path="/admin_dashboard" element={<Page23 />} />
      </Routes>
    </div>
  )
}
