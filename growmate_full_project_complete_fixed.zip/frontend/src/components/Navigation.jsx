import React from 'react'
import { Link } from 'react-router-dom'
const items = [
  {
    "path": "/",
    "label": "Home Page"
  },
  {
    "path": "/login__signup",
    "label": "Login / Signup"
  },
  {
    "path": "/user_profile",
    "label": "User Profile"
  },
  {
    "path": "/daily_planner__to-do",
    "label": "Daily Planner / To-Do"
  },
  {
    "path": "/calendar",
    "label": "Calendar"
  },
  {
    "path": "/study_timer",
    "label": "Study Timer"
  },
  {
    "path": "/reminder_and_notifications",
    "label": "Reminder & Notifications"
  },
  {
    "path": "/period_tracker",
    "label": "Period Tracker"
  },
  {
    "path": "/stress_level_quiz",
    "label": "Stress Level Quiz"
  },
  {
    "path": "/feedback_engine",
    "label": "Feedback Engine"
  },
  {
    "path": "/breathing_exercises",
    "label": "Breathing Exercises"
  },
  {
    "path": "/gratitude_journal",
    "label": "Gratitude Journal"
  },
  {
    "path": "/weekly_reflection_page",
    "label": "Weekly Reflection Page"
  },
  {
    "path": "/mood_journal",
    "label": "Mood Journal"
  },
  {
    "path": "/habit_tracker",
    "label": "Habit Tracker"
  },
  {
    "path": "/affirmation_generator",
    "label": "Affirmation Generator"
  },
  {
    "path": "/goal_tracker",
    "label": "Goal Tracker"
  },
  {
    "path": "/achievement_badges",
    "label": "Achievement Badges"
  },
  {
    "path": "/resource_library",
    "label": "Resource Library"
  },
  {
    "path": "/theme_customization",
    "label": "Theme Customization"
  },
  {
    "path": "/export_center",
    "label": "Export Center"
  },
  {
    "path": "/settings_and_privacy",
    "label": "Settings & Privacy"
  },
  {
    "path": "/admin_dashboard",
    "label": "Admin Dashboard"
  }
]

export default function Navigation(){
  return (
    <nav className="gm-nav">
      <div className="gm-brand">GrowMate</div>
      <div className="gm-links">
        {items.map((it,idx)=>(
          <Link key={idx} to={it.path} className="gm-link">{it.label}</Link>
        ))}
      </div>
    </nav>
  )
}
