import React from 'react'
import Logo from '../assets/logos/09_stress_level_quiz.png'

export default function Page9() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Stress Level Quiz</h1>
      <p>This is the Stress Level Quiz page.</p>
      <div id="special-9">
      </div>
    </div>
  )
}