import React from 'react'
import Logo from '../assets/logos/19_resource_library.png'

export default function Page19() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Resource Library</h1>
      <p>This is the Resource Library page.</p>
      <div id="special-19">
      </div>
    </div>
  )
}