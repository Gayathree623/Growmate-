import React from 'react'
import Logo from '../assets/logos/14_mood_journal.png'

export default function Page14() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Mood Journal</h1>
      <p>This is the Mood Journal page.</p>
      <div id="special-14">
      </div>
    </div>
  )
}