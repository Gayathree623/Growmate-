import React from 'react'
import Logo from '../assets/logos/13_weekly_reflection_page.png'

export default function Page13() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Weekly Reflection Page</h1>
      <p>This is the Weekly Reflection Page page.</p>
      <div id="special-13">
      </div>
    </div>
  )
}