import React from 'react'
import Logo from '../assets/logos/07_reminder_and_notifications.png'

export default function Page7() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Reminder & Notifications</h1>
      <p>This is the Reminder & Notifications page.</p>
      <div id="special-7">
      </div>
    </div>
  )
}