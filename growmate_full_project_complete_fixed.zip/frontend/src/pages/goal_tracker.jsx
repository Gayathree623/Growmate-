import React from 'react'
import Logo from '../assets/logos/17_goal_tracker.png'

export default function Page17() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Goal Tracker</h1>
      <p>This is the Goal Tracker page.</p>
      <div id="special-17">
      </div>
    </div>
  )
}