import React from 'react'
import Logo from '../assets/logos/04_daily_planner_to-do.png'

export default function Page4() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Daily Planner / To-Do</h1>
      <p>This is the Daily Planner / To-Do page.</p>
      <div id="special-4">
      </div>
    </div>
  )
}