import React from 'react'
import Logo from '../assets/logos/02_login_signup.png'

export default function Page2() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Login / Signup</h1>
      <p>This is the Login / Signup page.</p>
      <div id="special-2">
      </div>
    </div>
  )
}