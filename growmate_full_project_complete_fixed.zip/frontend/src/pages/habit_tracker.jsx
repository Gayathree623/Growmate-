import React from 'react'
import Logo from '../assets/logos/15_habit_tracker.png'

export default function Page15() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Habit Tracker</h1>
      <p>This is the Habit Tracker page.</p>
      <div id="special-15">
      </div>
    </div>
  )
}