import React from 'react'
import Logo from '../assets/logos/21_export_center.png'

export default function Page21() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Export Center</h1>
      <p>This is the Export Center page.</p>
      <div id="special-21">
      </div>
    </div>
  )
}