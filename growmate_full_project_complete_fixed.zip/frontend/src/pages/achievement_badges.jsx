import React from 'react'
import Logo from '../assets/logos/18_achievement_badges.png'

export default function Page18() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Achievement Badges</h1>
      <p>This is the Achievement Badges page.</p>
      <div id="special-18">
      </div>
    </div>
  )
}