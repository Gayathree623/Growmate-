import React from 'react'
import Logo from '../assets/logos/08_period_tracker.png'

export default function Page8() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Period Tracker</h1>
      <p>This is the Period Tracker page.</p>
      <div id="special-8">
      </div>
    </div>
  )
}