import React from 'react'
import Logo from '../assets/logos/12_gratitude_journal.png'

export default function Page12() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Gratitude Journal</h1>
      <p>This is the Gratitude Journal page.</p>
      <div id="special-12">
      </div>
    </div>
  )
}