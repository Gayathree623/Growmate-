import React from 'react'
import Logo from '../assets/logos/06_study_timer.png'

export default function Page6() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Study Timer</h1>
      <p>This is the Study Timer page.</p>
      <div id="special-6">
      </div>
    </div>
  )
}