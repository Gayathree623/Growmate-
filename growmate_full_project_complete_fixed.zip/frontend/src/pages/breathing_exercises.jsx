import React from 'react'
import Logo from '../assets/logos/11_breathing_exercises.png'

export default function Page11() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Breathing Exercises</h1>
      <p>This is the Breathing Exercises page.</p>
      <div id="special-11">
      </div>
    </div>
  )
}