import React from 'react'
import Logo from '../assets/logos/22_settings_and_privacy.png'

export default function Page22() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Settings & Privacy</h1>
      <p>This is the Settings & Privacy page.</p>
      <div id="special-22">
      </div>
    </div>
  )
}