import React from 'react'
import Logo from '../assets/logos/03_user_profile.png'

export default function Page3() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>User Profile</h1>
      <p>This is the User Profile page.</p>
      <div id="special-3">
      </div>
    </div>
  )
}