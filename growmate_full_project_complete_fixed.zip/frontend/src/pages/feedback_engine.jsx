import React from 'react'
import Logo from '../assets/logos/10_feedback_engine.png'

export default function Page10() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Feedback Engine</h1>
      <p>This is the Feedback Engine page.</p>
      <div id="special-10">
      </div>
    </div>
  )
}