import React from 'react'
import Logo from '../assets/logos/20_theme_customization.png'

export default function Page20() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Theme Customization</h1>
      <p>This is the Theme Customization page.</p>
      <div id="special-20">
      </div>
    </div>
  )
}