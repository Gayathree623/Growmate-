import React from 'react'
import Logo from '../assets/logos/05_calendar.png'

export default function Page5() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Calendar</h1>
      <p>This is the Calendar page.</p>
      <div id="special-5">
      </div>
    </div>
  )
}