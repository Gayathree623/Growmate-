import React from 'react'
import Logo from '../assets/logos/23_admin_dashboard.png'

export default function Page23() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Admin Dashboard</h1>
      <p>This is the Admin Dashboard page.</p>
      <div id="special-23">
      </div>
    </div>
  )
}