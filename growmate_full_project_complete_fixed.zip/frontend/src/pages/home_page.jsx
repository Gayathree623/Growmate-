import React from 'react'
import Logo from '../assets/logos/01_home_page.png'

export default function Page1() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Home Page</h1>
      <p>This is the Home Page page.</p>
      <div id="special-1">
      </div>
    </div>
  )
}