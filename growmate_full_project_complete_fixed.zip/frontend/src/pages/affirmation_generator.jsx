import React from 'react'
import Logo from '../assets/logos/16_affirmation_generator.png'

export default function Page16() {
  return (
    <div style={{ padding: 40 }}>
      <img src={Logo} alt="logo" style={{ width: 96, height: 96, borderRadius: 12 }} />
      <h1>Affirmation Generator</h1>
      <p>This is the Affirmation Generator page.</p>
      <div id="special-16">
      </div>
    </div>
  )
}