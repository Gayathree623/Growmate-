const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createGoal } = require('../controllers/goalController');

router.post('/', auth, createGoal);

module.exports = router;