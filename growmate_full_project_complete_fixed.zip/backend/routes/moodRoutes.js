const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { addMood } = require('../controllers/moodController');

router.post('/', auth, addMood);

module.exports = router;