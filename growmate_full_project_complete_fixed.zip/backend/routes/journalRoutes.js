const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { addEntry } = require('../controllers/journalController');

router.post('/', auth, addEntry);

module.exports = router;