const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createHabit, getHabits } = require('../controllers/habitController');

router.post('/', auth, createHabit);
router.get('/', auth, getHabits);

module.exports = router;