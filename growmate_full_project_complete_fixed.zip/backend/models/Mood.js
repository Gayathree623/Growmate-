const mongoose = require('mongoose');

const MoodSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  mood: String,
  note: String,
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Mood', MoodSchema);