const Feedback = require('../models/Feedback');

exports.sendFeedback = async (req, res) => {
  try {
    const fb = new Feedback({ ...req.body, user: req.userId });
    await fb.save();
    res.json(fb);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};