const Journal = require('../models/Journal');

exports.addEntry = async (req, res) => {
  try {
    const entry = new Journal({ ...req.body, user: req.userId });
    await entry.save();
    res.json(entry);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};