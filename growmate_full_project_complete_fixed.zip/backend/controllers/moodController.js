const Mood = require('../models/Mood');

exports.addMood = async (req, res) => {
  try {
    const mood = new Mood({ ...req.body, user: req.userId });
    await mood.save();
    res.json(mood);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};