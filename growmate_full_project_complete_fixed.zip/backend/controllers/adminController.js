exports.health = async (req, res) => {
  res.json({ status: 'ok' });
};