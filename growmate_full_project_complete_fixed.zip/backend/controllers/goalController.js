const Goal = require('../models/Goal');

exports.createGoal = async (req, res) => {
  try {
    const goal = new Goal({ ...req.body, user: req.userId });
    await goal.save();
    res.json(goal);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};