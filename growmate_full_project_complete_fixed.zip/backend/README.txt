GrowMate Backend
----------------
1. cd backend
2. npm install
3. copy .env.example to .env and fill values
4. npm run dev   # uses nodemon
5. API endpoints are mounted under /api/*

Auth:
POST /api/auth/register
POST /api/auth/login

Tasks:
GET /api/tasks
POST /api/tasks

(ensure JWT in Authorization: Bearer <token>)